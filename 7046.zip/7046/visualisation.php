<html>
<head>
<title>Social Barometer powered by FusionCharts Suite XT</title>
<style>
body {
    margin: 0;
    padding: 0;
    width: 100%;
    background-color: #00406A;
    font-family: Tahoma, Helvetica, Arial, sans-serif;
}
h1, h2, h3, h4, h5 {
    margin: 0;
    padding: 0;
    font-weight: bold;
}
.chartCont {
    padding: 0px 12px;
}
.border-bottom {
    border-bottom: 1px dashed rgba(0, 117, 194, 0.2);
}
.border-right {
    border-right: 1px dashed rgba(0, 117, 194, 0.2);
}
#container {
    width: 1200px;
    margin: 0 auto;
    position: relative;
}
#container> div {
    width: 100%;
    background-color: #ffffff;
}
#logoContainer {
    float: left;
}
#logoContainer img {
    padding: 0 10px;
}
#logoContainer div {
    position: absolute;
    top: 8px;
    left: 95px;
}
#logoContainer div h2 {
    color: #0075c2;
}
#logoContainer div h4 {
    color: #0e948c;
}
#logoContainer div p {
    color: #719146;
    font-size: 12px;
    padding: 5px 0;
}

#userDetail {
    float: right;
}
#userDetail img {
    position: absolute;
    top: 16px;
    right: 130px;
}
#userDetail div {
    position: absolute;
    top: 15px;
    right: 20px;
    font-size: 14px;
    font-weight: bold;
    color: #0075c2;
}
#userDetail div p {
    margin: 0;
}
#userDetail div p:nth-child(2) {
    color: #0e948c;
}
#header div:nth-child(3) {
    clear: both;
    border-bottom: 1px solid #0075c2;
}
#content div {
    display: inline-block;
}
#content > div {
    margin: 0px 20px;
}
#content > div:nth-child(1) > div {
    margin: 20px 0 0;
}
#content > div:nth-child(2) > div {
    margin: 0 0 20px;
}
#footer p {
    margin: 0;
    font-size: 9pt;
    color: black;
    padding: 5px 0;
    text-align: center;
}
</style>
<script type="text/javascript" src="fusioncharts/js/fusioncharts.js"></script>
<script type="text/javascript" src="fusioncharts/js/themes/fusioncharts.theme.fint.js"></script>
<script type="text/javascript">
FusionCharts.ready(function () {

 	   var needsByProvince = new FusionCharts({
        "type": "maps/southafrica",
        "renderAt": "needsMapContainer",
        "width": "500",
        "height": "300",
        "dataFormat": "json",
        "dataSource":{
            "chart": {
                "caption": "Total Needs by Province",
                "subcaption": "Last year",
                "entityFillHoverColor": "#cccccc",
                "numberScaleValue": "1,1000,1000",
                "numberScaleUnit": "K,M,B",
                "numberPrefix": "",
                "showLabels": "1",
                "theme": "fint"
            },
            "colorrange": {
                "minvalue": "0",
                "startlabel": "Low",
                "endlabel": "High",
                "code": "#e44a00",
                "gradient": "1",
                "color": [
                    {
                        "maxvalue": "56580",
                        "displayvalue": "Average",
                        "code": "#f8bd19"
                    },
                    {
                        "maxvalue": "100000",
                        "code": "#6baa01"
                    }
                ]
            },
            "data": [
                {
                    "id": "05",
                    "value": "50512"
                },
                {
                    "id": "06",
                    "value": "2879"
                },
                {
                    "id": "03",
                    "value": "920"
                },
                {
                    "id": "02",
                    "value": "4607"
                },
                {
                    "id": "09",
                    "value": "4890"
                },
                {
                    "id": "07",
                    "value": "34927"
                },
                {
                    "id": "10",
                    "value": "65798"
                },
                {
                    "id": "08",
                    "value": "61861"
                },
                {
                    "id": "11",
                    "value": "58911"
                }
            ]
        }
    }).render();
	
 var havesByProvince = new FusionCharts({
        "type": "maps/southafrica",
        "renderAt": "havesMapContainer",
        "width": "500",
        "height": "300",
        "dataFormat": "json",
        "dataSource":{
            "chart": {
                "caption": "Total Haves by Province",
                "subcaption": "Last year",
                "entityFillHoverColor": "#cccccc",
                "numberScaleValue": "1,1000,1000",
                "numberScaleUnit": "K,M,B",
                "numberPrefix": "R",
                "showLabels": "1",
                "theme": "fint"
            },
            "colorrange": {
                "minvalue": "0",
                "startlabel": "Low",
                "endlabel": "High",
                "code": "#e44a00",
                "gradient": "1",
                "color": [
                    {
                        "maxvalue": "56580",
                        "displayvalue": "Average",
                        "code": "#f8bd19"
                    },
                    {
                        "maxvalue": "100000",
                        "code": "#6baa01"
                    }
                ]
            },
            "data": [
                {
                    "id": "05",
                    "value": "50512"
                },
                {
                    "id": "06",
                    "value": "2879"
                },
                {
                    "id": "03",
                    "value": "920"
                },
                {
                    "id": "02",
                    "value": "4607"
                },
                {
                    "id": "09",
                    "value": "4890"
                },
                {
                    "id": "07",
                    "value": "34927"
                },
                {
                    "id": "10",
                    "value": "65798"
                },
                {
                    "id": "08",
                    "value": "61861"
                },
                {
                    "id": "11",
                    "value": "58911"
                }
            ]
        }
    }).render();

	    var needsChart = new FusionCharts({
        "type": "column2d",
        "renderAt": "needsChartContainer",
        "width": "500",
        "height": "300",
        "dataFormat": "json",
        "dataSource":  {
          "chart": {
            "caption": "Selected Province Needs",
            "subCaption": "Harry's SuperMart",
            "xAxisName": "Month",
            "yAxisName": "Revenues (In USD)",
            "theme": "fint"
         },
         "data": [
            {
               "label": "Jan",
               "value": "420000"
            },
            {
               "label": "Feb",
               "value": "810000"
            },
            {
               "label": "Mar",
               "value": "720000"
            },
            {
               "label": "Apr",
               "value": "550000"
            },
            {
               "label": "May",
               "value": "910000"
            },
            {
               "label": "Jun",
               "value": "510000"
            },
            {
               "label": "Jul",
               "value": "680000"
            },
            {
               "label": "Aug",
               "value": "620000"
            },
            {
               "label": "Sep",
               "value": "610000"
            },
            {
               "label": "Oct",
               "value": "490000"
            },
            {
               "label": "Nov",
               "value": "900000"
            },
            {
               "label": "Dec",
               "value": "730000"
            }
          ]
      }

  }).render();

	    var havesChart = new FusionCharts({
        "type": "column2d",
        "renderAt": "havesChartContainer",
        "width": "500",
        "height": "300",
        "dataFormat": "json",
        "dataSource":  {
          "chart": {
            "caption": "Selected Province Haves",
            "subCaption": "Harry's SuperMart",
            "xAxisName": "Month",
            "yAxisName": "Revenues (In USD)",
            "theme": "fint"
         },
         "data": [
            {
               "label": "Jan",
               "value": "420000"
            },
            {
               "label": "Feb",
               "value": "810000"
            },
            {
               "label": "Mar",
               "value": "720000"
            },
            {
               "label": "Apr",
               "value": "550000"
            },
            {
               "label": "May",
               "value": "910000"
            },
            {
               "label": "Jun",
               "value": "510000"
            },
            {
               "label": "Jul",
               "value": "680000"
            },
            {
               "label": "Aug",
               "value": "620000"
            },
            {
               "label": "Sep",
               "value": "610000"
            },
            {
               "label": "Oct",
               "value": "490000"
            },
            {
               "label": "Nov",
               "value": "900000"
            },
            {
               "label": "Dec",
               "value": "730000"
            }
          ]
      }

  }).render();

})
</script>
</head>
<body>
<div id='container'>
    <div id='header'>
        <div id='logoContainer'>
            <img src="http://static.fusioncharts.com/sampledata/images/Logo-HM-72x72.png" alt='Logo' />
            <div>
                  <h2>Social Barometer</h2>

                  <h4>Los Angeles Topanga</h4>
                    <p>Today: 4th June, 2014</p>

            </div>
        </div>
        <div id='userDetail'>
            <img src="http://static.fusioncharts.com/sampledata/images/user_image.jpg" alt='Logo' />
            <div>
                <p>Welcome John</p>
                <p>Store Manager</p>
            </div>
        </div>
        <div></div>
    </div>
    <div class='border-bottom' id='content'>
      <div class='border-bottom'>
        <div class='chartCont border-right' id='needsMapContainer'>FusionCharts will load here.</div>
        <div class='chartCont' id='havesMapContainer'>FusionCharts will load here.</div>
      </div>
      <div>
        <div class='chartCont border-right' id='needsChartContainer'>FusionCharts will load here.</div>
        <div class='chartCont' id='havesChartContainer'>FusionCharts will load here.</div>
      </div>
    </div>
    <div id='footer'>
        <p>This application was built using <a href="http://www.fusioncharts.com" target="_blank" title="FusionCharts - Data to delight... in minutes"><b>FusionCharts Suite XT</b></a>
</p>
    </div>
</div>
</body>
</html>