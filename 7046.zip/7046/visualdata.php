<?php
//address of the server where db is installed
$servername = "localhost";
//username to connect to the db
//the default value is root
$username = "test";
//password to connect to the db
//this is the value you would have specified during installation of WAMP stack
$password = "YPMU7MfTf53BshAB";
//name of the db under which the table is created
$dbName = "waronpoverty";
//establishing the connection to the db.
$conn = new mysqli($servername, $username, $password, $dbName);
//checking if there were any error during the last connection attempt
$defaultYear = 2015;
$defaultMinimum = 10000000000;
$defaultMaximum = 0;
$defaultAverage = 0;
$defaultSelection ="Documentation";

function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 //$current_url = str_replace("www.", "", curPageURL());
 /*
 $query = parse_url('http://www.example.com?test=123&random=abc', PHP_URL_QUERY);
parse_str($query, $params);

$test = $params['test'];
 */
 return $pageURL;
}

function get_province_id($province)
{
$province_id = "0";
if($province == "Eastern Cape")
{
$province_id = "05";
}
if($province =="Free State")
{
$province_id = "03";
}
if($province == "Gauteng")
{
$province_id = "06";
}
if($province =="KwaZulu-Natal")
{
$province_id = "02";
}
if($province =="Limpopo")
{
$province_id = "09";
}
if($province =="Mpumalanga")
{
$province_id = "07";
}
if($province == "North West")
{
$province_id = "10";
}
if($province =="Northern Cape")
{
$province_id = "08";
}
if($province == "Western Cape")
{
$province_id = "11";
}

return $province_id;
}
/*ID	Short label	Label
05	EC	Eastern Cape
03	FS	Free State
06	GT	Gauteng
02	NL	KwaZulu-Natal
09	LP	Limpopo
07	MP	Mpumalanga
10	NW	North West
08	NC	Northern Cape
11	WC	Western Cape
*/



if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//the SQL query to be executed
$query = "SELECT CaptureYear,Province,sum(TotalDocNeeds) as TotalForYear
FROM `tbl_7046provincedistrictlocaldocumentationneedssummary`
WHERE CaptureYear =".$defaultYear."
GROUP BY Province
ORDER BY  CaptureYear,Province,TotalDocNeeds ASC";
//storing the result of the executed query
$result = $conn->query($query);
//initialize the array to store the processed data
$jsonArray = array();
//check if there is any data returned by the SQL Query
if ($result->num_rows > 0) {
  //Converting the results into an associative array
  while($row = $result->fetch_assoc()) {
    $jsonArrayItem = array();
    $jsonArrayItem['label'] = $row['Province'];
	 $jsonArrayItem['id'] = get_province_id($row['Province']);
    $jsonArrayItem['value'] = $row['TotalForYear'];
	if($defaultMinimum >$row['TotalForYear'])
	{$defaultMinimum = $row['TotalForYear'];}
	if($defaultMaximum <$row['TotalForYear'])
	{$defaultMaximum = $row['TotalForYear'];}
    //append the above created object into the main array.
    array_push($jsonArray, $jsonArrayItem);
  }
  $defaultAverage = ($defaultMaximum + $defaultMinimum)/2;
}
//Closing the connection to DB
$conn->close();
//echo "Minimum: ".$defaultMinimum. " Average: ".$defaultAverage." Maximum: ".$defaultMaximum."<p>";
//set the response content type as JSON
header('Content-type: application/json');
//output the return value of json encode using the echo function. 
echo json_encode($jsonArray);

