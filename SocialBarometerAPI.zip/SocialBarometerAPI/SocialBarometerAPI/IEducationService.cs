﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SocialEducationService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IEducationService
    {

        // get the education needs for the specific year at province level
        [OperationContract]
        [WebGet(UriTemplate = "/getEducationNeeds/{year}", ResponseFormat = WebMessageFormat.Json)]
        needsWrapper getEducationNeeds(string year);

        [OperationContract]
        [WebGet(UriTemplate = "/getEducationNeedsAll/{year}", ResponseFormat = WebMessageFormat.Json)]
        needsWrapper getEducationNeedsAll(string year);

        [OperationContract]
        [WebGet(UriTemplate = "/getEducationNeedsYearProvince/{year}/{province}", ResponseFormat = WebMessageFormat.Json)]
        needsWrapper getEducationNeedsYearProvince(string year, string province);

        [OperationContract]
        [WebGet(UriTemplate = "/getEducationWalks/{year}", ResponseFormat = WebMessageFormat.Json)]
        List<EducationWalkToSchool> getEducationWalks(string year);

        [OperationContract]
        [WebGet(UriTemplate = "/getEducationHaves/{year}", ResponseFormat = WebMessageFormat.Json)]
        havesWrapper getEducationHaves(string year);

        [OperationContract]
        [WebGet(UriTemplate = "/getEducationHavesYearProvince/{year}/{province}", ResponseFormat = WebMessageFormat.Json)]
        havesWrapper getEducationHavesYearProvince(string year, string province);
    }

    [DataContract]
    public class Education
    {
        [DataMember(Name = "year")]
        public string Year
        {
            get; set;
        }

        [DataMember(Name = "label")]
        public string Province
        {
            get; set;
        }

        [DataMember(Name = "id")]
        public string ProvinceID
        {
            get; set;
        }

        [DataMember(Name = "district")]
        public string District
        {
            get; set;
        }

        [DataMember(Name = "local")]
        public string Local
        {
            get; set;
        }

        [DataMember(Name = "link")]
        public string Link
        {
            get; set;
        }
    }

    [DataContract]
    public class EducationHaves : Education
    {
        [DataMember(Name = "noschooling")]
        public string NoSchooling
        {
            get; set;
        }

        [DataMember(Name = "someprimary")]
        public string SomePrimary
        {
            get; set;
        }

        [DataMember(Name = "primaryfinished")]
        public string PrimaryFinished
        {
            get; set;
        }

        [DataMember(Name = "secondaryfinished")]
        public string SecondaryFinished
        {
            get; set;
        }

        [DataMember(Name = "secondaryschool")]
        public string SecondarySchool
        {
            get; set;
        }

        [DataMember(Name = "tertiary")]
        public string Tertiary
        {
            get; set;
        }

        [DataMember(Name = "notselected")]
        public string NotSelected
        { get; set; }

        [DataMember(Name = "value")]
        public string TotalHaves
        { get; set; }

    }

    [DataContract]
    public class EducationNeeds : Education
    {
        [DataMember(Name = "feeding")]
        public string Feeding
        { get; set; }

        [DataMember(Name = "transport")]
        public string Transport
        { get; set; }

        [DataMember(Name = "fees")]
        public string Fees
        { get; set; }

        [DataMember(Name = "textbooks")]
        public string Textbooks
        { get; set; }

        [DataMember(Name = "abet")]
        public string ABET
        { get; set; }

        [DataMember(Name = "educationneed")]
        public string EducationNeed
        { get; set; }

        [DataMember(Name = "value")]
        public string TotalNeeds
        { get; set; }
    }

    [DataContract]
    public class EducationWalkToSchool : Education
    {
        [DataMember(Name = "totalwalks")]
        public Int32 TotalWalks
        { get; set; }

        [DataMember(Name = "lessfifteen")]
        public Int32 Less15Mins
        { get; set; }

        [DataMember(Name = "fifteenthirty")]
        public Int32 FifteenThirty
        { get; set; }

        [DataMember(Name = "thirtysixty")]
        public Int32 ThirtySixty
        { get; set; }

        [DataMember(Name = "sixtyninety")]
        public Int32 SixtyNinety
        { get; set; }

        [DataMember(Name = "ninety")]
        public Int32 Ninety
        { get; set; }

        [DataMember(Name = "dontknow")]
        public Int32 DontKnow
        { get; set; }

        [DataMember(Name = "notselected")]
        public Int32 NotSelected
        { get; set; }

    }

    [DataContract]
    public class infoData
    {
        // id values are : maximum, minimum and average
        [DataMember(Name = "id")]
        public string valueID
        { get; set; }

        [DataMember(Name = "value")]
        public string infoValue
        { get; set; }
       
    }

    [DataContract]
    public class needsWrapper
    {
        [DataMember (Name = "infodata")]
        public List<infoData> needsData
        {
            get; set;
        }

        [DataMember(Name = "mapData")]
        public List<EducationNeeds> needChart
        { get; set; }

        [DataMember(Name = "barChartYesData")]
        public List<EducationNeeds> needYesChart
        { get; set; }

        [DataMember(Name = "barChartNoData")]
        public List<EducationNeeds> needNoChart
        { get; set; }

        [DataMember(Name = "barChartNotSelectedData")]
        public List<EducationNeeds> needNSChart
        { get; set; }

        [DataMember(Name = "columnData")]
        public List<EducationNeeds> columnChart
        { get; set; }

    }

    [DataContract]
    public class havesWrapper
    {
        [DataMember(Name = "infodata")]
        public List<infoData> havesData
        {
            get; set;
        }

        [DataMember(Name = "mapData")]
        public List<EducationHaves> havesChart
        { get; set; }
    }
}

