﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Web.Script.Serialization;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace SocialEducationService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class EducationService : IEducationService
    {
        //string connectionString = ConfigurationManager.ConnectionStrings.ToString();//"Server=winmysqls03.cpt.wa.co.za;Port=3307;Uid=wits03;Pwd=Pr0ject;Database=waronpoverty;";
        //string connectionString = "Server=winmysqls03.cpt.wa.co.za;Port=3307;Uid=wits03;Pwd=Pr0ject;Database=waronpoverty;";
        string connectionString = "Server=localhost;Port=3306;Uid=root;Pwd=;Database=waronpoverty;";

        string getProvinceID(string province)
        {
            switch (province)
            {
                case "Eastern Cape":
                    return "05";
                case "Free State":
                    return "03";
                case "Gauteng":
                    return "06";
                case "Northern Cape":
                    return "08";
                case "Western Cape":
                    return "11";
                case "North West":
                    return "10";
                case "Mpumalanga":
                    return "07";
                case "Kwazulu-Natal":
                    return "02";
                case "Limpopo":
                    return "09";
            }
            return "00";
        }

        string getSQLString(int groupby, int havesneeds)
        {
            string strselect = "";
            string strgroup = "";
            string strwhere = "";
            string strmid = "";


            switch (groupby)
            {
                case 0: // group by year only
                    strselect += "select captureyear,";
                    strwhere += " where captureyear = @year";
                    strgroup += " group by captureyear ";
                    break;
                case 1: // group by year and province
                    strselect += "select captureyear, province,";
                    strwhere += " where captureyear = @year ";
                    strgroup += " group by captureyear, province ";
                    break;
                case 2: // group by year, province and district
                    strselect += "select captureyear, province,district,";
                    strwhere += " where captureyear = @year and province = @province";
                    strgroup += " group by captureyear,province,district ";

                    break;
                case 3: // group by year, province, district and localmunicipality
                    strselect += "select captureyear, province,district, localmunicipality";
                    strwhere += " where captureyear = @year and province = @province and district = @district";
                    strgroup += " group by captureyear,province,district,localmunicipality ";

                    break;
                case 4: // select all the data
                    strselect += "select captureyear, province,district, localmunicipality,";
                    //strwhere += " where captureyear = @year";
                    //strgroup += " group by captureyear,province,district,localmunicipality ";

                    break;
            }
            
            switch (havesneeds)
            {
                case 1: // SQL string for the Education Haves
                    strmid += "sum(case when LevelOfEducation = 'Some primary education' then TotalLevelOfEducation end) as SomePrimary,"
                        + "sum(case when LevelOfEducation = 'Primary education finished' then TotalLevelOfEducation end) as PrimaryFinished,"
                        + "sum(case when LevelOfEducation = 'Some Secondary Education' then TotalLevelOfEducation end) as SecondarySchool,"
                        + "sum(case when LevelOfEducation = 'Secondary Education Finished' then TotalLevelOfEducation end) as SecondaryFinished,"
                        + "sum(case when LevelOfEducation = 'Tertiary Education' then TotalLevelOfEducation end) as Tertiary,"
                        + "sum(case when LevelOfEducation = 'No schooling' then TotalLevelOfEducation end) as NoSchooling,"
                        + "sum(case when LevelOfEducation = 'NOT Found' then TotalLevelOfEducation end) as NotSelected,"
                        + " sum(TotalLevelOfEducation) as TotalHaves"
                        + " from tbl_7046provincedistrictlocaleducationhaves";
                    break;
                case 2: // SQL string for the Education Needs
                    strselect += "educationneeds,";
                    strmid += "sum(totalneededucationservicefeeding) as TotalFeeding"
                        + ", sum(totalneededucationtextbooks) as TotalTextbooks, sum(totalneededucationserviceabet) as TotalABET"
                        + ", sum(totalneededucationservicescholartransport) as TotalScholarTransport "
                        + ", sum(totalneededucationservicefees) as TotalFees, sum(totaleducationserviceneeds) as TotalNeeds"
                        + " from tbl_7046provincedistrictlocaleducationneeds";
                    strgroup += " ,educationneeds";
                    break;
                case 3: // select all the needs 
                    strselect += "educationneeds,";
                    strmid += "totalneededucationservicefeeding as TotalFeeding"
                        + ", totalneededucationtextbooks as TotalTextbooks, totalneededucationserviceabet as TotalABET"
                        + ", totalneededucationservicescholartransport as TotalScholarTransport "
                        + ", totalneededucationservicefees as TotalFees, totaleducationserviceneeds as TotalNeeds"
                        + " from tbl_7046provincedistrictlocaleducationneeds";
                    strgroup += " order by captureyear, province, district, localmunicipality";
                    break;
            }

            return strselect + strmid + strwhere+ strgroup;
        }

        public needsWrapper getEducationNeedsAll(string year)
        {
            try
            { 
                needsWrapper needswrapper = new needsWrapper();
                List<infoData> needsinfo = new List<infoData>();
                List<EducationNeeds> educationneeds = new List<EducationNeeds>();

                using (MySqlConnection connection = new MySqlConnection())
                {
                    connection.ConnectionString = connectionString;
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();

                    // add the year parameter
                    command.CommandText = getSQLString(4, 3);
                    command.Parameters.AddWithValue("@year", year);
                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        EducationNeeds educationneed = new EducationNeeds();
                        educationneed.Year = Convert.ToString(reader["CaptureYear"]);
                        educationneed.Province = Convert.ToString(reader["Province"]);
                        educationneed.ProvinceID = Convert.ToString(getProvinceID(educationneed.Province));
                        educationneed.District = Convert.ToString(reader["District"]);
                        educationneed.Local = Convert.ToString(reader["LocalMunicipality"]);
                        educationneed.EducationNeed = Convert.ToString(reader["EducationNeeds"]);
                        educationneed.Feeding = Convert.ToString(reader["TotalFeeding"]);
                        educationneed.Fees = Convert.ToString(reader["TotalFees"]);
                        educationneed.Textbooks = Convert.ToString(reader["TotalTextbooks"]);
                        educationneed.ABET = Convert.ToString(reader["TotalABET"]);
                        educationneed.Transport = Convert.ToString(reader["TotalScholarTransport"]);
                        educationneed.TotalNeeds = Convert.ToString(reader["TotalNeeds"]);
                        educationneed.Link = "getEducationNeedsYearProvince/" + year + "/" + educationneed.Province;

                        educationneeds.Add(educationneed);
                    }
                }

                infoData minneeddata = new infoData();

                //needdata
                minneeddata.valueID = "minimum";
                minneeddata.infoValue = Convert.ToString(educationneeds.Min(educationneed => Convert.ToInt32(educationneed.TotalNeeds)));
                needsinfo.Add(minneeddata);

                infoData maxneeddata = new infoData();
                maxneeddata.valueID = "maximum";
                maxneeddata.infoValue = Convert.ToString(educationneeds.Max(educationneed => Convert.ToInt32(educationneed.TotalNeeds)));
                needsinfo.Add(maxneeddata);

                infoData avgneeddata = new infoData();
                avgneeddata.valueID = "average";
                avgneeddata.infoValue = Convert.ToString(educationneeds.Average(educationneed => Convert.ToInt32(educationneed.TotalNeeds)));
                needsinfo.Add(avgneeddata);

                // convert to lists
                educationneeds.ToList();
                needsinfo.ToList();

                needswrapper.needsData = needsinfo;

                needswrapper.needChart = educationneeds;

                return needswrapper;
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message); 
            }

        }

        public needsWrapper getEducationNeeds(string year)
        {
            try
            {
                needsWrapper needswrapper = new needsWrapper();
                List<infoData> needsinfo = new List<infoData>();

                List<EducationNeeds> educationneeds = new List<EducationNeeds>();
                List<EducationNeeds> educationneedsYes = new List<EducationNeeds>();
                List<EducationNeeds> educationneedsNo = new List<EducationNeeds>();
                List<EducationNeeds> educationneedsNS = new List<EducationNeeds>();
                List<EducationNeeds> educationneedscolumn = new List<EducationNeeds>();

                using (MySqlConnection connection = new MySqlConnection())
                {
                    connection.ConnectionString = connectionString;
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();

                    // add the year parameter
                    command.CommandText = getSQLString(1, 2);
                    command.Parameters.AddWithValue("@year", year);
                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        switch(Convert.ToString(reader["EducationNeeds"]))
                        {
                            case "Yes":
                                EducationNeeds educationneedYes = new EducationNeeds();
                                educationneedYes.Year = Convert.ToString(reader["CaptureYear"]);
                                educationneedYes.Province = Convert.ToString(reader["Province"]);
                                educationneedYes.ProvinceID = Convert.ToString(getProvinceID(educationneedYes.Province));
                                educationneedYes.Feeding = Convert.ToString(reader["TotalFeeding"]);
                                educationneedYes.Fees = Convert.ToString(reader["TotalFees"]);
                                educationneedYes.Textbooks = Convert.ToString(reader["TotalTextbooks"]);
                                educationneedYes.ABET = Convert.ToString(reader["TotalABET"]);
                                educationneedYes.Transport = Convert.ToString(reader["TotalScholarTransport"]);
                                educationneedYes.TotalNeeds = Convert.ToString(reader["TotalNeeds"]);
                                educationneedYes.Link = "getEducationNeedsYearProvince/" + year + "/" + educationneedYes.Province;
  
                                educationneedsYes.Add(educationneedYes);
                                break;
                            case "No":
                                EducationNeeds educationneedNo = new EducationNeeds();
                                educationneedNo.Year = Convert.ToString(reader["CaptureYear"]);
                                educationneedNo.Province = Convert.ToString(reader["Province"]);
                                educationneedNo.ProvinceID = Convert.ToString(getProvinceID(educationneedNo.Province));
                                educationneedNo.Feeding = Convert.ToString(reader["TotalFeeding"]);
                                educationneedNo.Fees = Convert.ToString(reader["TotalFees"]);
                                educationneedNo.Textbooks = Convert.ToString(reader["TotalTextbooks"]);
                                educationneedNo.ABET = Convert.ToString(reader["TotalABET"]);
                                educationneedNo.Transport = Convert.ToString(reader["TotalScholarTransport"]);
                                educationneedNo.TotalNeeds = Convert.ToString(reader["TotalNeeds"]);
                                educationneedNo.Link = "getEducationNeedsYearProvince/" + year + "/" + educationneedNo.Province;

                                educationneedsNo.Add(educationneedNo);
                                break;
                            case "Not Selected":
                                EducationNeeds educationneedNS = new EducationNeeds();
                                educationneedNS.Year = Convert.ToString(reader["CaptureYear"]);
                                educationneedNS.Province = Convert.ToString(reader["Province"]);
                                educationneedNS.ProvinceID = Convert.ToString(getProvinceID(educationneedNS.Province));
                                educationneedNS.Feeding = Convert.ToString(reader["TotalFeeding"]);
                                educationneedNS.Fees = Convert.ToString(reader["TotalFees"]);
                                educationneedNS.Textbooks = Convert.ToString(reader["TotalTextbooks"]);
                                educationneedNS.ABET = Convert.ToString(reader["TotalABET"]);
                                educationneedNS.Transport = Convert.ToString(reader["TotalScholarTransport"]);
                                educationneedNS.TotalNeeds = Convert.ToString(reader["TotalNeeds"]);
                                educationneedNS.Link = "getEducationNeedsYearProvince/" + year + "/" + educationneedNS.Province;

                                educationneedsNo.Add(educationneedNS);
                                break;
                        }

                    }

                    educationneedsYes.ToList();
                    educationneedsNo.ToList();
                    educationneedsNS.ToList();

                    // the map data is for Yes needs
                    educationneeds = educationneedsYes;

                    infoData minneeddata = new infoData();

                    //needdata
                    minneeddata.valueID = "minimum";
                    minneeddata.infoValue = Convert.ToString(educationneeds.Min(educationneed => Convert.ToInt32(educationneed.TotalNeeds)));
                    needsinfo.Add(minneeddata);

                    infoData maxneeddata = new infoData();
                    maxneeddata.valueID = "maximum";
                    maxneeddata.infoValue = Convert.ToString(educationneeds.Max(educationneed => Convert.ToInt32(educationneed.TotalNeeds)));
                    needsinfo.Add(maxneeddata);

                    infoData avgneeddata = new infoData();
                    avgneeddata.valueID = "average";
                    avgneeddata.infoValue = Convert.ToString(educationneeds.Average(educationneed => Convert.ToDouble(educationneed.TotalNeeds)));
                    needsinfo.Add(avgneeddata);

                    needsinfo.ToList();

                    // generate data for the column chart displaying the totals for the different Needs sub categories
                    EducationNeeds educationneedfeed = new EducationNeeds();
                    educationneedfeed.Province = "Feeding";
                    educationneedfeed.ProvinceID = "feed";
                    educationneedfeed.TotalNeeds = Convert.ToString(educationneeds.Sum(educationneed => Convert.ToDouble(educationneed.Feeding)));
                    educationneedfeed.Link = "getEducationNeedsYearProvince/" + year; //+ "/" + educationneed.Province;
                    educationneedscolumn.Add(educationneedfeed);

                    EducationNeeds educationneedtext = new EducationNeeds();
                    educationneedtext.Province = "Textbooks";
                    educationneedtext.ProvinceID = "text";
                    educationneedtext.TotalNeeds = Convert.ToString(educationneeds.Sum(educationneed => Convert.ToDouble(educationneed.Textbooks))) ;
                    educationneedtext.Link = "getEducationNeedsYearProvince/" + year; ;
                    educationneedscolumn.Add(educationneedtext);

                    EducationNeeds educationneedabet = new EducationNeeds();
                    educationneedabet.Province = "ABET";
                    educationneedabet.ProvinceID = "abet";
                    educationneedabet.TotalNeeds = Convert.ToString(educationneeds.Sum(educationneed => Convert.ToDouble(educationneed.ABET)));
                    educationneedabet.Link = "getEducationNeedsYearProvince/" + year; ;
                    educationneedscolumn.Add(educationneedabet);

                    EducationNeeds educationneedtrans = new EducationNeeds();
                    educationneedtrans.Province = "Transport";
                    educationneedtrans.ProvinceID = "trans";
                    educationneedtrans.TotalNeeds = Convert.ToString(educationneeds.Sum(educationneed => Convert.ToDouble(educationneed.Transport)));
                    educationneedtrans.Link = "getEducationNeedsYearProvince/" + year; 
                    educationneedscolumn.Add(educationneedtrans);

                    EducationNeeds educationneedfees = new EducationNeeds();
                    educationneedfees.Province = "Fees";
                    educationneedfees.ProvinceID = "fees";
                    educationneedfees.TotalNeeds = Convert.ToString(educationneeds.Sum(educationneed => Convert.ToDouble(educationneed.Fees)));
                    educationneedfees.Link = "getEducationNeedsYearProvince/" + year; 
                    educationneedscolumn.Add(educationneedfees);

                    educationneedscolumn.ToList();

                    needswrapper.columnChart = educationneedscolumn;
                    needswrapper.needYesChart = educationneedsYes;
                    needswrapper.needNoChart = educationneedsNo;
                    needswrapper.needNSChart = educationneedsNS;
                    needswrapper.needsData = needsinfo;

                    // the map data is for Yes needs
                    needswrapper.needChart = educationneedsYes;

                    return needswrapper;
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public needsWrapper getEducationNeedsYearProvince(string year, string province)
        {
            try
            {
                needsWrapper needswrapper = new needsWrapper();
                List<infoData> needsinfo = new List<infoData>();

                List<EducationNeeds> educationneeds = new List<EducationNeeds>();

                //list of values/totalneeds
                //Int32[] totalneeds = new Int32[];

                using (MySqlConnection connection = new MySqlConnection())
                {
                    connection.ConnectionString = connectionString;
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();

                    // add the year parameter
                    command.CommandText = getSQLString(2, 2); //
                    command.Parameters.AddWithValue("@year", year);
                    command.Parameters.AddWithValue("@province", province);
                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        EducationNeeds educationneed = new EducationNeeds();
                        educationneed.Year = Convert.ToString(reader["CaptureYear"]);
                        educationneed.Province = Convert.ToString(reader["Province"]);
                        educationneed.ProvinceID = Convert.ToString(getProvinceID(educationneed.Province));
                        educationneed.District = Convert.ToString(reader["District"]);
                        educationneed.Feeding = Convert.ToString(reader["TotalFeeding"]);
                        //educationneed.EducationNeed = Convert.ToString(reader["EducationNeeds"]);
                        educationneed.Textbooks = Convert.ToString(reader["TotalTextbooks"]);
                        educationneed.ABET = Convert.ToString(reader["TotalABET"]);
                        educationneed.Transport = Convert.ToString(reader["TotalScholarTransport"]);
                        educationneed.TotalNeeds = Convert.ToString(reader["TotalNeeds"]);
                        educationneed.Link = "getEducationNeedsYearProvince";

                        educationneeds.Add(educationneed);

                    }

                    educationneeds.ToList();

                    infoData minneeddata = new infoData();

                    //needdata
                    minneeddata.valueID = "minimum";
                    minneeddata.infoValue = Convert.ToString(educationneeds.Min(educationneed => Convert.ToInt32(educationneed.TotalNeeds)));
                    needsinfo.Add(minneeddata);

                    infoData maxneeddata = new infoData();
                    maxneeddata.valueID = "maximum";
                    maxneeddata.infoValue = Convert.ToString(educationneeds.Max(educationneed => Convert.ToInt32(educationneed.TotalNeeds)));
                    needsinfo.Add(maxneeddata);

                    infoData avgneeddata = new infoData();
                    avgneeddata.valueID = "average";
                    avgneeddata.infoValue = Convert.ToString(educationneeds.Average(educationneed => Convert.ToDouble(educationneed.TotalNeeds)));
                    needsinfo.Add(avgneeddata);

                    needsinfo.ToList();

                    needswrapper.needsData = needsinfo;
                    needswrapper.needChart = educationneeds;

                    return needswrapper;
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public List<EducationWalkToSchool> getEducationWalks(string year)
        {
            List<EducationWalkToSchool> educationwalks = new List<EducationWalkToSchool>();

            //string connectionString = "Server=winmysqls03.cpt.wa.co.za;Port=3307;Uid=wits03;Pwd=Pr0ject;Database=waronpoverty;";
            using (MySqlConnection connection = new MySqlConnection())
            {
                connection.ConnectionString = connectionString;
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                string sql = "select CaptureYear,Province, "
                    + " sum(case when TimeToWalkToSchool = 'Do not know' then TotalTimeToWalkToSchool else 0 end) as DontKnow,"
                    + " sum(case when TimeToWalkToSchool = 'Less than 15 minutes' then TotalTimeToWalkToSchool else 0 end) as LessFifteen,"
                    + " sum(case when TimeToWalkToSchool = '15 - 30 minutes' then TotalTimeToWalkToSchool else 0 end) as FifteenThirty,"
                    + "sum(case when TimeToWalkToSchool = '31 - 60 minutes' then TotalTimeToWalkToSchool else 0 end) as ThirtySixty,"
                    + " sum(case when TimeToWalkToSchool = '61 - 90 minutes' then TotalTimeToWalkToSchool else 0 end) as SixtyNinety,"
                    + " sum(case when TimeToWalkToSchool = 'more than 90 minutes' then TotalTimeToWalkToSchool else 0 end) as Ninety,"
                    + " sum(case when TimeToWalkToSchool = 'Not selected' then TotalTimeToWalkToSchool else 0 end) as NotSelected"
                    + " from tbl_7046provincedistrictlocaltimetowalktoschool"
                    + " where captureyear = @year"
                    + " and TimeToWalkToSchool NOT IN ('NOT AVAILABLE FOR THIS SITE')"
                    + " group by captureyear,province";

                // add the year parameter
                command.CommandText = sql;
                command.Parameters.AddWithValue("@year", year);
                MySqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    EducationWalkToSchool educationwalk = new EducationWalkToSchool();
                    educationwalk.Year = Convert.ToString(reader["CaptureYear"]);
                    educationwalk.Province = Convert.ToString(reader["Province"]);
                    educationwalk.District = Convert.ToString(reader["District"]);
                    educationwalk.ProvinceID = Convert.ToString(getProvinceID(educationwalk.Province));
                    educationwalk.DontKnow = Convert.ToInt32(reader["DontKnow"]);
                    educationwalk.Less15Mins = Convert.ToInt32(reader["LessFifteen"]);
                    educationwalk.FifteenThirty = Convert.ToInt32(reader["FifteenThirty"]);
                    educationwalk.ThirtySixty = Convert.ToInt32(reader["ThirtySixty"]);
                    educationwalk.SixtyNinety = Convert.ToInt32(reader["SixtyNinety"]);
                    educationwalk.Ninety = Convert.ToInt32(reader["Ninety"]);
                    educationwalk.NotSelected = Convert.ToInt32(reader["NotSelected"]);
                    educationwalk.Link = "getEducationWalksYearProvince";
                    
                    educationwalks.Add(educationwalk);
                }

            }
                educationwalks.ToList();
                return educationwalks;
            }

        public havesWrapper getEducationHaves(string year)
        {
            havesWrapper haveswrapper = new havesWrapper();
            List<infoData> havesinfo = new List<infoData>();

            List<EducationHaves> educationhaves = new List<EducationHaves>();

            try
            {
                using (MySqlConnection connection = new MySqlConnection())
                {
                    connection.ConnectionString = connectionString;
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();
                    
                    // add the year parameter 
                    command.CommandText = getSQLString(1,1);
                    command.Parameters.AddWithValue("@year", year);
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        EducationHaves educationhave = new EducationHaves();
                        educationhave.Year = Convert.ToString(reader["CaptureYear"]);
                        educationhave.Province = Convert.ToString(reader["Province"]);
                        educationhave.ProvinceID = Convert.ToString(getProvinceID(educationhave.Province));
                        educationhave.NoSchooling = Convert.ToString(reader["NoSchooling"]);
                        educationhave.SomePrimary = Convert.ToString(reader["SomePrimary"]);
                        educationhave.PrimaryFinished = Convert.ToString(reader["PrimaryFinished"]);
                        educationhave.SecondarySchool = Convert.ToString(reader["SecondarySchool"]);
                        educationhave.SecondaryFinished = Convert.ToString(reader["SecondaryFinished"]);
                        educationhave.Tertiary = Convert.ToString(reader["Tertiary"]);
                        educationhave.NotSelected = Convert.ToString(reader["NotSelected"]);
                        educationhave.TotalHaves = Convert.ToString(reader["TotalHaves"]);
                        educationhave.Link = "getEducationHavesYearProvince/" + year + "/" + educationhave.Province;

                        educationhaves.Add(educationhave);
                    }

                    connection.Close();
                }

                educationhaves.ToList();

                //havesdata
                infoData minhavedata = new infoData();

                minhavedata.valueID = "minimum";
                minhavedata.infoValue = Convert.ToString(educationhaves.Min(educationhave => Convert.ToInt32(educationhave.TotalHaves)));
                havesinfo.Add(minhavedata);

                infoData maxhavedata = new infoData();
                maxhavedata.valueID = "maximum";
                maxhavedata.infoValue = Convert.ToString(educationhaves.Max(educationhave => Convert.ToInt32(educationhave.TotalHaves)));
                havesinfo.Add(maxhavedata);

                infoData avghavedata = new infoData();
                avghavedata.valueID = "average";
                avghavedata.infoValue = Convert.ToString(educationhaves.Average(educationhave => Convert.ToDouble(educationhave.TotalHaves)));
                havesinfo.Add(avghavedata);

                havesinfo.ToList();

                haveswrapper.havesData = havesinfo;
                haveswrapper.havesChart = educationhaves;
                
                return haveswrapper;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public havesWrapper getEducationHavesYearProvince(string year, string province)
        {
            havesWrapper haveswrapper = new havesWrapper();
            List<infoData> havesinfo = new List<infoData>();

            List<EducationHaves> educationhaves = new List<EducationHaves>();

            try
            {
                //string connectionString = "Server=winmysqls03.cpt.wa.co.za;Port=3307;Uid=wits03;Pwd=Pr0ject;Database=waronpoverty;";
                using (MySqlConnection connection = new MySqlConnection())
                {
                    connection.ConnectionString = connectionString;
                    connection.Open();
                    MySqlCommand command = connection.CreateCommand();
  
                    // add the year and province parameters
                    command.CommandText = getSQLString(2,1);
                    command.Parameters.AddWithValue("@year", year);
                    command.Parameters.AddWithValue("@province", province);
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        EducationHaves educationhave = new EducationHaves();
                        educationhave.Year = Convert.ToString(reader["CaptureYear"]);
                        educationhave.Province = Convert.ToString(reader["Province"]);
                        educationhave.ProvinceID = Convert.ToString(getProvinceID(educationhave.Province));
                        educationhave.District = Convert.ToString(reader["District"]);
                        educationhave.NoSchooling = Convert.ToString(reader?["NoSchooling"]);
                        educationhave.SomePrimary = Convert.ToString(reader?["SomePrimary"]);
                        educationhave.PrimaryFinished = Convert.ToString(reader?["PrimaryFinished"]);
                        educationhave.SecondarySchool = Convert.ToString(reader?["SecondarySchool"]);
                        educationhave.SecondaryFinished = Convert.ToString(reader?["SecondaryFinished"]);
                        educationhave.Tertiary = Convert.ToString(reader?["Tertiary"]);
                        educationhave.NotSelected = Convert.ToString(reader?["NotSelected"]);
                        educationhave.TotalHaves = Convert.ToString(reader?["TotalHaves"]);

                        educationhaves.Add(educationhave);
                    }

                    connection.Close();
                }

                infoData minhavedata = new infoData();

                minhavedata.valueID = "minimum";
                minhavedata.infoValue = Convert.ToString(educationhaves.Min(educationhave => Convert.ToInt32(educationhave.TotalHaves)));
                havesinfo.Add(minhavedata);

                infoData maxhavedata = new infoData();
                maxhavedata.valueID = "maximum";
                maxhavedata.infoValue = Convert.ToString(educationhaves.Max(educationhave => Convert.ToInt32(educationhave.TotalHaves)));
                havesinfo.Add(maxhavedata);

                infoData avghavedata = new infoData();
                avghavedata.valueID = "average";
                avghavedata.infoValue = Convert.ToString(educationhaves.Average(educationhave => Convert.ToDouble(educationhave.TotalHaves)));
                havesinfo.Add(avghavedata);

                havesinfo.ToList();

                haveswrapper.havesData = havesinfo;
                haveswrapper.havesChart = educationhaves;
                educationhaves.ToList();

                return haveswrapper;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

    }
    }


