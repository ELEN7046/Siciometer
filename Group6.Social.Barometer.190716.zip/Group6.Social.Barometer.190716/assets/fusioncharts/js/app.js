$(function(){
  $.ajax({
   // url: 'http://localhost/7046/bigdata.php?server=localhost&username=test&password=YPMU7MfTf53BshAB&database=waronpoverty&table=tbl_7046provincedistrictlocaldocumentationneedssummary&selection=Documentation&year=2015',
     url: 'http://localhost/7046/bigdata.php?selection=Documentation&year=2014',
	type: 'GET',
    success : function(data) {
       chartData = data.chartData;
	   infoData = data.infoData;
	   var selection = "";
	    var year = "";
		var minimum = "";
		var maximum = "";
		var average = "";
	    var items = data.infoData.map(function (item) {
			if(item.id == "selection")
			{selection = item.value;}
		   if(item.id == "year")
			{year = item.value;}
			if(item.id == "minimum")
			{minimum = item.value;}
		   if(item.id == "average")
			{average = item.value;}
			if(item.id == "maximum")
			{maximum = item.value;}
		
        return item.id + ': ' + item.value;
      });
	   
      var chartProperties = {
        "caption": "Selected "+selection+" Needs",
        "xAxisName": "Province",
        "yAxisName": selection+'',
        "rotatevalues": "1",
        "theme": "zune"
      };
	  var mapProperties = {
                "caption": 'Total '+selection+' Needs by Province',
                "subcaption": year,
                "entityFillHoverColor": "#cccccc",
                "numberScaleValue": "1,1000,1000",
                "numberScaleUnit": ",K,M",
                "numberPrefix": "",
                "showLabels": "1",
                "theme": "zune"
      };
	  
	  /*
      apiChart = new FusionCharts({
        type: 'column2d',
        renderAt: 'needsChartContainer',
        width: '550',
        height: '350',
        dataFormat: 'json',
        dataSource: {
          "chart": chartProperties,
          "data": chartData
        }
      });
      apiChart.render();
	  */
	  
	var needsByProvince = new FusionCharts({
        type: "maps/southafrica",
        renderAt: "needsMapContainer",
        width: "500",
        height: "300",
        dataFormat: "json",
        dataSource:{
            "chart": mapProperties,
            "colorrange": {
                "minvalue": minimum,
                "startlabel": "Low",
                "endlabel": "High",
                "code": "#6baa01",
                "gradient": "1",
                "color": [
                    {
                        "maxvalue": average,
                        "displayvalue": "Average",
                        "code": "#f8bd19"
                    },
                    {
                        "maxvalue": maximum,
                        "code": "#e44a00"
                    }
                ]
            },
            "data": chartData
        }
    }).render();
	  
	  
	  
	  
    }
  });
});