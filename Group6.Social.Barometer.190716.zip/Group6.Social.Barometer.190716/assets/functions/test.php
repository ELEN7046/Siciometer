<?php
require_once('globalFunctions.php');

$fusioncharts = readXMLConfigs('..\config\fusioncharts.xml');// readXMLConfigs(realpath('').'\assets\config\fusioncharts.xml');
	//$postfix = 'Array';
	//$parametersArray = array('Chart');
	//$_SESSION['Chart'.$postfix] = array();
	foreach ($fusioncharts->chart as $chart) {
	echo 'id:'.(string)$chart->id.'</br/>';
	echo 'type:'.(string)$chart->type.'</br/>';
	echo 'width:'.(string)$chart->width.'</br/>';
	echo 'height:'.(string)$chart->height.'</br/>';
	echo 'dataFormat:'.(string)$chart->dataFormat.'</br/>';
	echo 'renderAt:'.(string)$chart->renderAt.'</br/>';
	if((string)$chart->id =='map')
	{
			echo 'gradient:'.(string)$chart->slider['gradient'].'</br/>';
			echo 'startLabel:'.(string)$chart->slider->low['label'].'</br/>';
			echo 'startColor:'.(string)$chart->slider->low['color'].'</br/>';
			echo 'midLabel:'.(string)$chart->slider->mid['label'].'</br/>';
			echo 'midColor:'.(string)$chart->slider->mid['color'].'</br/>';
			echo 'endLabel:'.(string)$chart->slider->high['label'].'</br/>';
			echo 'endColor:'.(string)$chart->slider->high['color'].'</br/>';
	}
echo 'EntityHoverColor:'.(string)$chart['entityFillHoverColor'].'</br/>';
echo 'showLabels:'.(string)$chart['showLabels'].'</br/>';
echo 'theme:'.(string)$chart['theme'].'</br/>';
echo 'numbers prefix:'.(string)$chart->numbers['prefix'].'</br/>';
echo 'numbers scale:'.(string)$chart->numbers->scale['unit'].'</br/>';

}

function print_array($name,$array,$array_cols)
{
echo "
<br/>[".$name."]:<br/>
<table border='1'>
<tr>
";
	for($count=0; $count<count($array_cols);++$count)
	{
echo "<td><b>". $array_cols[$count]."</b></td>";
	}
echo "</tr>";

	for($count_a=0; $count_a<count($array);++$count_a)
	{
		echo "
<tr>";
		for($count_c=0; $count_c<count($array_cols);++$count_c)
		{
	     echo "<td>". $array[$count_a][$array_cols[$count_c]]."</td>";
		}
       echo "
	  </tr>";
	}
	
echo "
</table>
<br/>

";
/*
	for($count=0; $count<count($array);++$count)
	{
		
		
echo "| ". $array[$count]." ";
	}

	testArray = col1 + col2 + col3 + Province + District       + CaptureYear
              12 + 5    +  6   + Gauteng  + Johannesburg   + 2011
              10 + 100  +  1   + Gauteng  + Ekurhuleni     + 2011			  
              6  + 20   +  12  + Limpopo  + Johannesburg   + 2011
              5  + 33   +  44  + Limpopo  + Polokwane      + 2012
              8  + 16   +  3   + Gauteng  + Johannesburg   + 2012
			  	*/
}


$base = __DIR__ . "/../";
echo 'base is:'.$base;
echo 'path is:'.realpath('..');
 echo'Page URL: '. $_SERVER["SCRIPT_NAME"];
  echo'Page URL: '. $_SERVER["REQUEST_URI"];
 $string_pos0 = strripos($_SERVER["REQUEST_URI"],"test.php",0);
 echo' Modified Page URL: '.substr($_SERVER["REQUEST_URI"],0,$string_pos0);
 
 /***
 
 
 
 ***/
 
function array_unit_test($test_array,$test_array_columns,$test_expected_array,$function_name) 
{

echo"<br/>==========begin unit test=========<br/>";
echo 'Testing function: '.$function_name.'($inputArray,$inputArrayColumns)';
$name = '$inputArray';		
print_array($name,$test_array,$test_array_columns);

//print_r($test_array);
$name = '$ expectedArray';		
print_array($name,$test_expected_array,$test_array_columns);
$name ='$outputArray';	
$test_result_array=$function_name($test_array,$test_array_columns);
print_array($name,$test_result_array,$test_array_columns);
if($test_result_array==$test_expected_array)
{
	echo '<font color="green"><b>SUCCESS!!!</b></font>';
}
else
{
	echo '<font color="red"><b>FAILURE</b></font>';
}
echo"<br/>==========end test=========<br/>";
	
}
	$test_array_columns = array('col1','col2','col3');
	$test_array = array();
	$test_array_item = array();
	$test_expected_array = array();
	$test_array_item['col1'] = 12;
	$test_array_item['col2'] = 5;
	$test_array_item['col3'] = 6;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 10;
	$test_array_item['col2'] = 100;
	$test_array_item['col3'] = 1;
	array_push($test_array,$test_array_item);

	$test_array_item['col1'] = 22;
	$test_array_item['col2'] = 105;
	$test_array_item['col3'] = 7;
	array_push($test_expected_array,$test_array_item);	
 
array_unit_test($test_array,$test_array_columns,$test_expected_array,"sumArrayByColumns");


//function filterInputArrayByParameter($inputArray,$filterParam,$filterValue)
echo"<br/>==========begin unit test=========<br/>";
echo 'Testing function: filterInputArrayByParameter($inputArray,$filterParam,$filterValue)';
echo '<br/>$inputArray=';	
	$test_array_columns = array('col1','col2','col3','Province','District','CaptureYear');
	$test_array = array();
	$test_array_item = array();
	$test_expected_array = array();
	$test_array_item['col1'] = 12;
	$test_array_item['col2'] = 5;
	$test_array_item['col3'] = 6;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 10;
	$test_array_item['col2'] = 100;
	$test_array_item['col3'] = 1;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Ekurhuleni';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 6;
	$test_array_item['col2'] = 20;
	$test_array_item['col3'] = 12;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 5;
	$test_array_item['col2'] = 33;
	$test_array_item['col3'] = 44;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Polokwane';
	$test_array_item['CaptureYear'] = 2012;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 8;
	$test_array_item['col2'] = 16;
	$test_array_item['col3'] = 3;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2012;
	array_push($test_array,$test_array_item);

print_array("test_array",$test_array,$test_array_columns);

$test_col = 'Province';
$test_col_val = 'Limpopo';
echo '<br/>$filterParam = '.$test_col;	
echo '<br/>$filterValue = '.$test_col_val;	
echo '<br/>expected $outputArray=';		
	$test_array_item['col1'] = 6;
	$test_array_item['col2'] = 20;
	$test_array_item['col3'] = 12;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_expected_array,$test_array_item);
	$test_array_item['col1'] = 5;
	$test_array_item['col2'] = 33;
	$test_array_item['col3'] = 44;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Polokwane';
	$test_array_item['CaptureYear'] = 2012;
	array_push($test_expected_array,$test_array_item);
	
print_array("expected_array",$test_expected_array,$test_array_columns);

echo '<br/>actual $outputArray=';	
$test_result_array=filterInputArrayByParameter($inputArray=$test_array,$filterParam=$test_col,$test_col_val);

print_array("result_array",$test_result_array,$test_array_columns);

if($test_result_array==$test_expected_array)
{
	echo '<br/>SUCCESS';
}
else
{
	echo '<br/>FAILURE';
}
echo"<br/>==========end test=========<br/>";

//function summarizeArrayByParameter($inputArray,$inputArrayColumns,$summaryField)
echo"<br/>==========begin unit test=========<br/>";
echo 'Testing function: summarizeArrayByParameter($inputArray,$inputArrayColumns,$summaryField)';
echo '<br/>$inputArray=';	
	$test_array_columns = array('col1','col2','col3','Province','District','CaptureYear');
	$test_array = array();
	$test_array_item = array();
	$test_expected_array = array();
	$test_array_item['col1'] = 12;
	$test_array_item['col2'] = 5;
	$test_array_item['col3'] = 6;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 10;
	$test_array_item['col2'] = 100;
	$test_array_item['col3'] = 1;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Ekurhuleni';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 6;
	$test_array_item['col2'] = 20;
	$test_array_item['col3'] = 12;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 5;
	$test_array_item['col2'] = 33;
	$test_array_item['col3'] = 44;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Polokwane';
	$test_array_item['CaptureYear'] = 2012;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 8;
	$test_array_item['col2'] = 16;
	$test_array_item['col3'] = 3;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2012;
	array_push($test_array,$test_array_item);
	
print_array("test_array",$test_array,$test_array_columns);

$test_col = 'CaptureYear';
echo '<br/>$summaryField = '.$test_col;	
echo '<br/>expected $outputArray=';		
	$test_array_item['col1'] = 30;
	$test_array_item['col2'] = 121;
	$test_array_item['col3'] = 10;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_expected_array,$test_array_item);
	$test_array_item['col1'] = 11;
	$test_array_item['col2'] = 53;
	$test_array_item['col3'] = 56;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_expected_array,$test_array_item);

print_array("expected_array",$test_expected_array,$test_array_columns);
echo '<br/>actual $outputArray=';	
$test_result_array=summarizeArrayByParameter($inputArray=$test_array,$inputArrayColumns=$test_array_columns,$summaryField=$test_col);
print_array("result_array",$test_result_array,$test_array_columns);

if($test_result_array==$test_expected_array)
{
	echo '<br/>SUCCESS';
}
else
{
	echo '<br/>FAILURE';
}
echo"<br/>==========end test=========<br/>";
	
	
//function filterInputArrayByParameter($inputArray,$filterParam,$filterValue)
echo"<br/>==========begin unit test=========<br/>";
echo 'Testing function: filterInputArrayByParameter($inputArray,$filterParam,$filterValue)';
echo '<br/>$inputArray=';	
/**
testArray = col1 + col2 + col3 + Province + District       + CaptureYear
              12 + 5    +  6   + Gauteng  + Johannesburg   + 2011
              10 + 100  +  1   + Gauteng  + Ekurhuleni     + 2011			  
              6  + 20   +  12  + Limpopo  + Johannesburg   + 2011
              5  + 33   +  44  + Limpopo  + Polokwane      + 2012
              8  + 16   +  3   + Gauteng  + Johannesburg   + 2012
**/
	$test_array_columns = array('col1','col2','col3','Province','District','CaptureYear');
	$test_array = array();
	$test_array_item = array();
	$test_expected_array = array();
	$test_array_item['col1'] = 12;
	$test_array_item['col2'] = 5;
	$test_array_item['col3'] = 6;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 10;
	$test_array_item['col2'] = 100;
	$test_array_item['col3'] = 1;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Ekurhuleni';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 6;
	$test_array_item['col2'] = 20;
	$test_array_item['col3'] = 12;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 5;
	$test_array_item['col2'] = 33;
	$test_array_item['col3'] = 44;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Polokwane';
	$test_array_item['CaptureYear'] = 2012;
	array_push($test_array,$test_array_item);
	$test_array_item['col1'] = 8;
	$test_array_item['col2'] = 16;
	$test_array_item['col3'] = 3;
	$test_array_item['Province'] = 'Gauteng';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2012;
	array_push($test_array,$test_array_item);
print_array("test_array",$test_array,$test_array_columns);

$test_col = 'CaptureYear';
$test_col_val = '2011';
echo '<br/>$filterParam = '.$test_col;	
echo '<br/>$filterValue = '.$test_col_val;	
echo '<br/>expected $outputArray=';		/**
outputArray = col1 + col2 + col3 + Province + District       + CaptureYear
              28   + 125  +  19   + Gauteng  + Johannesburg + 2011
              13   + 49   +  47  + Limpopo  + Polokwane      + 2012

**/

	$test_array_item['col1'] = 6;
	$test_array_item['col2'] = 20;
	$test_array_item['col3'] = 12;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Johannesburg';
	$test_array_item['CaptureYear'] = 2011;
	array_push($test_expected_array,$test_array_item);
	$test_array_item['col1'] = 5;
	$test_array_item['col2'] = 33;
	$test_array_item['col3'] = 44;
	$test_array_item['Province'] = 'Limpopo';
	$test_array_item['District'] = 'Polokwane';
	$test_array_item['CaptureYear'] = 2012;
	array_push($test_expected_array,$test_array_item);
print_array("expected_array",$test_expected_array,$test_array_columns);
echo '<br/>actual $outputArray=';	
$test_result_array=filterInputArrayByParameter($inputArray=$test_array,$filterParam=$test_col,$test_col_val);
print_array("result_array",$test_result_array,$test_array_columns);

if($test_result_array==$test_expected_array)
{
	echo '<br/>SUCCESS';
}
else
{
	echo '<br/>FAILURE';
}
echo"<br/>==========end test=========<br/>";