<?php
spl_autoload_register(function ($class_name){
	include 'assets/classes/'.$class_name.'.php';
});
include_once('assets\functions\globalFunctions.php');

class CreateColumnDataFormat
{
	protected $result_set_;
	protected $minimum_value_ ;
    protected $maximum_value_ ;

	public function __construct()
	{
	}

public function createFormat($input_array,$sum_columns,$sum_columns_labels)
{
	$this->result_set_ = array();
	
	for( $tmp_j = 0; $tmp_j < count($sum_columns); $tmp_j++)
	{
    $result_item["label"] = $sum_columns_labels[$tmp_j]; ;
	$result_item["id"] = $sum_columns[$tmp_j];
	$result_item["value"] = $input_array[0][$sum_columns[$tmp_j]];
	array_push($this->result_set_,$result_item);
	}
	unset($result_item);
}
	public function getResultSet(){ return $this->result_set_;}
	
	public function getMinimumValue(){ return $this->minimum_value_ ;}
	public function getMaximumValue(){ return $this->maximum_value_ ;}

	public function __destruct()
	{}


}
