<?php
spl_autoload_register(function ($class_name){
	include 'assets/classes/'.$class_name.'.php';
});
include_once('assets\functions\globalFunctions.php');

class CreateSeriesDataFormat
{
	protected $result_set_;
	protected $minimum_value_ ;
    protected $maximum_value_ ;
    protected $category_data_;
	public function __construct()
	{
	}

public function createFormat($input_array,$sum_columns,$sum_columns_labels,$sum_years)
{
	     $this->result_set_ = array();
		 $this->category_data_= array();
         $this->minimum_value_ = 100000000;
         $this->maximum_value_  = 0;
		for($tmp_i = 0; $tmp_i < count($sum_years); $tmp_i++)
		{
			$category_item["label"] = $sum_years[$tmp_i];
			array_push($this->category_data_,$category_item);
		}
	for( $tmp_j = 0; $tmp_j < count($sum_columns); $tmp_j++)
	{
		
		$series_data = array();
		for( $tmp_k = 0; $tmp_k < count($input_array); $tmp_k++)
		{
		if($this->minimum_value_ > $input_array[$tmp_k][$sum_columns[$tmp_j]])
		 {
			 $this->minimum_value_ = $input_array[$tmp_k][$sum_columns[$tmp_j]];
		 }
		 if($this->maximum_value_ < $input_array[$tmp_k][$sum_columns[$tmp_j]])
		 {
			 $this->maximum_value_ = $input_array[$tmp_k][$sum_columns[$tmp_j]];
		 }
	        $series_item["value"] = $input_array[$tmp_k][$sum_columns[$tmp_j]];
	        array_push($series_data,$series_item);
		}
		
    $result_item["seriesname"] = $sum_columns_labels[$tmp_j]; 
	$result_item["data"] = $series_data ;
	array_push($this->result_set_,$result_item);
	}
	unset($result_item);
}

	public function getResultSet(){ return $this->result_set_;}
	public function getCategories(){ return $this->category_data_;}
	
	public function getMinimumValue(){ return $this->minimum_value_ ;}
	public function getMaximumValue(){ return $this->maximum_value_ ;}

	public function __destruct()
	{}


}
