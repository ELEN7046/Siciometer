<?php
spl_autoload_register(function ($class_name){
	include 'assets/classes/'.$class_name.'.php';
});
include_once('assets\functions\globalFunctions.php');

class CreateChartString
{
	public function __construct()
	{
	}

public function create($chartDataFormat,$chart)
{
	$subcaption = '';
	$caption = 'Total '.$_SESSION['Profile'];	
	$data ='data';
	$dataSource = '
	dataSource: {
			          ';
	$jchart='
	"chart": {"caption": "'.$caption.'",
                "subcaption": "'.$subcaption.'",';
	$colorrange = '
	"colorrange": {
		';

	$categories ='
	"categories": [{
                   ';
				
	$trendlines ='
	"trendlines": [{
                ';
               
	$this->chart_ = '
		var '.(string)$chart->renderAt.' = new FusionCharts({
        type:"'.(string)$chart->type.'",
        renderAt:"'.(string)$chart->renderAt.'",
        width: "'.(string)$chart->width.'",
        height: "'.(string)$chart->height.'",
        dataFormat: "'.(string)$chart->dataFormat.'",
		';
		 switch((string)$chart->id)
		 {
			case 'map':		
			case 'pie':
			
			$jchart.='
			    "entityFillHoverColor": "'.(string)$chart['entityFillHoverColor'].'",
                "numberScaleValue": "'.(string)$chart->numbers->scale.'",
                "numberScaleUnit": "'.(string)$chart->numbers->scale['unit'].'",
                "numberPrefix": "'.(string)$chart->numbers['prefix'].'",
                "showLabels": "'.(string)$chart['showLabels'].'",
		        "theme": "'.(string)$chart['theme'].'"}';
			$dataSource .= $jchart;
			$dataSource .= ',';
         	$colorrange.= '
                "minvalue": "'.$chartDataFormat->getMinimumValue().'",
                "startlabel": "'.(string)$chart->slider->low['label'].'",
                "endlabel": "'.(string)$chart->slider->high['label'].'",
                "code": "'.(string)$chart->slider->low['color'].'",
                "gradient": "'.(string)$chart->slider['gradient'].'",
                "color": [
                    {
                        "maxvalue": "'.(($chartDataFormat->getMaximumValue()+$chartDataFormat->getMinimumValue())/2).'",
                        "displayvalue": "'.(string)$chart->slider->mid['label'].'",
                        "code": "'.(string)$chart->slider->mid['color'].'"
                    },
                    {
                        "maxvalue": "'.$chartDataFormat->getMaximumValue().'",
                        "code": "'.(string)$chart->slider->high['color'].'"
                    }
                ]
            }
			';
			$dataSource .= $colorrange;
			$dataSource .= ',';
            break;		 
			case 'series':
			$jchart.='
            "captionFontSize": "14",
            "subcaptionFontSize": "14",
            "subcaptionFontBold": "0",
            "paletteColors": "#ff75c2,#1aaf5d",
            "bgcolor": "#ffffff",
            "showBorder": "0",
            "showShadow": "0",
            "showCanvasBorder": "0",
            "usePlotGradientColor": "0",
            "legendBorderAlpha": "0",
            "legendShadow": "0",
            "showAxisLines": "0",
            "showAlternateHGridColor": "0",
            "divlineThickness": "1",
            "divLineIsDashed": "1",
            "divLineDashLen": "1",
            "divLineGapLen": "1",
            "xAxisName": "Year",
            "showValues": "0"}';
			$dataSource .= $jchart;
			$dataSource .= ',';
			$data ='dataset';
         	$categories.= '
                "category": '.json_encode($chartDataFormat->getCategories()).'
            }]';
			$dataSource .= $categories;
			$dataSource .= ',';
	        $trendlines.= '
            "line": [{
                "startvalue": "'.(($chartDataFormat->getMaximumValue()+$chartDataFormat->getMinimumValue())/2).'",
                "color": "#6baa01",
                "valueOnRight": "1",
                "displayvalue": "Average"
            }]
        }]';
			$dataSource .= $trendlines;
			$dataSource .= ',';

            break;
		 }

$this->chart_ .= $dataSource;
$this->chart_ .= '	 
		"'.$data.'": '.json_encode($chartDataFormat->getResultSet()).'
		        }
    }).render();
';

return $this->chart_;

}

	public function __destruct()
	{}


}
