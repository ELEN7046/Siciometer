<?php
spl_autoload_register(function ($class_name){
	include (realpath('').'\assets\classes\\'.$class_name.'.php');
});

include_once(realpath('').'\assets\functions\globalFunctions.php');

class CreateMapChartString extends CreateFusionChartString
{
	protected $colorrange_;
	
	public function __construct($chartDataFormat,$chart)
	{
		parent::__construct($chartDataFormat,$chart);

			$this->chartArray_["entityFillHoverColor"] = (string)$chart['entityFillHoverColor'];
            $this->chartArray_["numberScaleValue"] = (string)$chart->numbers->scale;
            $this->chartArray_[ "numberScaleUnit"] = (string)$chart->numbers->scale['unit'];
            $this->chartArray_["numberPrefix"] = (string)$chart->numbers['prefix'];
            $this->chartArray_["showLabels"] = (string)$chart['showLabels'];
		    $this->chartArray_["theme"] = (string)$chart['theme'];
			
			$this->colorrange_ = array();
			$this->colorrange_['minvalue'] = $chartDataFormat->getMinimumValue();
			$this->colorrange_['startlabel'] = (string)$chart->slider->low['label'];
			$this->colorrange_['endlabel'] = (string)$chart->slider->high['label'];
			$this->colorrange_['code'] = (string)$chart->slider->low['color'];
			$this->colorrange_['gradient'] = (string)$chart->slider['gradient'];
			
			$color_item_array = array();
			$color_item = array();
			$color_item['maxvalue'] = ($chartDataFormat->getMaximumValue()+$chartDataFormat->getMinimumValue())/2;
			$color_item['displayvalue'] = (string)$chart->slider->mid['label'];
			$color_item['code'] = (string)$chart->slider->mid['color'];
			array_push($color_item_array,$color_item);
			$color_item = array();
			$color_item['maxvalue'] = $chartDataFormat->getMaximumValue();
			$color_item['code'] = (string)$chart->slider->high['color'];
			array_push($color_item_array,$color_item);
			
			$this->colorrange_['color'] = $color_item_array;
			
			$this->dataSource_['chart'] = $this->chartArray_;
			$this->dataSource_['colorrange'] = $this->colorrange_;
			$this->dataSource_['data'] = $this->data_;
			
			$this->chartString_['dataSource'] = $this->dataSource_;

	}

	public function __destruct()
	{}


}
