<?php
spl_autoload_register(function ($class_name){
	include (realpath('').'\assets\classes\\'.$class_name.'.php');
});

include_once(realpath('').'\assets\functions\globalFunctions.php');

class CreateColumnChartString extends CreateFusionChartString
{
	protected $colorrange_;
	
	public function __construct($chartDataFormat,$chart)
	{
		parent::__construct($chartDataFormat,$chart);
			
			$this->dataSource_['data'] = $this->data_;
			$this->chartString_['dataSource'] = $this->dataSource_;
	}

	public function __destruct()
	{}


}
