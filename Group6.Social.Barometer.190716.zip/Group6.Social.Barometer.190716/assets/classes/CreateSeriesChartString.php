<?php
spl_autoload_register(function ($class_name){
	include (realpath('').'\assets\classes\\'.$class_name.'.php');
});

include_once(realpath('').'\assets\functions\globalFunctions.php');

class CreateSeriesChartString extends CreateFusionChartString
{

	public function __construct($chartDataFormat,$chart)
	{
		parent::__construct($chartDataFormat,$chart);

			$this->chartArray_["captionFontSize"] = (string)$chart['captionFontSize'];
			$this->chartArray_["subcaptionFontSize"] = (string)$chart['subcaptionFontSize'];
			$this->chartArray_["subcaptionFontBold"] = (string)$chart['subcaptionFontBold'];
			$this->chartArray_["paletteColors"] = (string)$chart['paletteColors'];
			$this->chartArray_["bgcolor"] = (string)$chart['bgcolor'];
			$this->chartArray_["showBorder"] = (string)$chart['showBorder'];
			$this->chartArray_["showShadow"] = (string)$chart['showShadow'];
			$this->chartArray_["showCanvasBorder"] = (string)$chart['showCanvasBorder'];
			$this->chartArray_["usePlotGradientColor"] = (string)$chart['usePlotGradientColor'];
			$this->chartArray_["legendBorderAlpha"] = (string)$chart['legendBorderAlpha'];
			$this->chartArray_["legendShadow"] = (string)$chart['legendShadow'];
			$this->chartArray_["showAxisLines"] = (string)$chart['showAxisLines'];
			$this->chartArray_["showAlternateHGridColor"] = (string)$chart['showAlternateHGridColor'];
			$this->chartArray_["divlineThickness"] = (string)$chart['divlineThickness'];
			$this->chartArray_["divLineIsDashed"] = (string)$chart['divLineIsDashed'];
			$this->chartArray_["divLineDashLen"] = (string)$chart['divLineDashLen'];
			$this->chartArray_["divLineGapLen"] = (string)$chart['divLineGapLen'];
			$this->chartArray_["xAxisName"] = (string)$chart['xAxisName'];
			$this->chartArray_["showValues"] = (string)$chart['showValues'];
			
			$this->categories_ = $chartDataFormat->getCategories();

			
			$trendlines_array = array();
			$trendlines = array();
			$line = array();
			$line_item = array();
			$line_item['startvalue'] = ($chartDataFormat->getMaximumValue()+$chartDataFormat->getMinimumValue())/2; 
			$line_item['color'] = (string)$chart->line['color'];
			$line_item['valueOnRight'] = (string)$chart->line['valueOnRight'];
			$line_item['displayvalue'] = (string)$chart->line['displayvalue'];
		//	$trendlines_array['line'] =$line_item;
			array_push($line,$line_item);
			$trendlines['line'] =$line;
			array_push($trendlines_array,$trendlines);
			
			$categories_array = array();
			$categories = array();
			$categories['category'] = $chartDataFormat->getCategories();
			array_push($categories_array,$categories);
			
			$this->dataSource_['chart'] = $this->chartArray_;
			
			$this->dataSource_['categories'] = $categories_array;
			$this->dataSource_['trendlines'] = $trendlines_array;
			$this->dataSource_['dataset'] = $this->data_;
			
			$this->chartString_['dataSource'] = $this->dataSource_;

	}

	public function __destruct()
	{}


}
