<?php
spl_autoload_register(function ($class_name){
	include 'assets/classes/'.$class_name.'.php';
});
include_once('assets\functions\globalFunctions.php');

class CreateMapDataFormat
{
	protected $result_set_;
	
	protected $minimum_value_ ;
    protected $maximum_value_ ;

	public function __construct()
	{
	}

public function extractMapData($input_array,$sum_column,$extraction_level)
{
	     $this->result_set_ = array();
         $this->minimum_value_ = 100000000;
         $this->maximum_value_  = 0;
		 for( $tmp_j = 0; $tmp_j < count($input_array); $tmp_j++)
		 {
		 if($this->minimum_value_ > $input_array[$tmp_j][$sum_column])
		 {
			 $this->minimum_value_ = $input_array[$tmp_j][$sum_column];
		 }
		 if($this->maximum_value_ < $input_array[$tmp_j][$sum_column])
		 {
			 $this->maximum_value_ = $input_array[$tmp_j][$sum_column];
		 }
    $result_item["label"] = $input_array[$tmp_j][$extraction_level];
	$result_item["id"] = get_province_id($input_array[$tmp_j]['Province']);
	$result_item["value"] = $input_array[$tmp_j][$sum_column];
	$result_item ["link"] = createLinkURL($extraction_level,$input_array[$tmp_j][$extraction_level]);
	
	array_push($this->result_set_,$result_item);
		 }
		unset($result_item);
}

	public function __destruct()
	{}


}
