<?php
spl_autoload_register(function ($class_name){
	include (realpath('').'\assets\classes\\'.$class_name.'.php');
});

include_once(realpath('').'\assets\functions\globalFunctions.php');


class CreateFusionChartString
{
	protected $chartString_;
	protected $chartArray_;
	protected $data_;
	protected $dataSource_;
	
	
	public function __construct($chartDataFormat,$chart)
	{
	$this->chartString_ = array();
	$this->chartString_['type'] = (string)$chart->type;
    $this->chartString_['renderAt'] = (string)$chart->renderAt;
    $this->chartString_['width'] =  (string)$chart->width;
    $this->chartString_['height'] = (string)$chart->height;
    $this->chartString_['dataFormat'] = (string)$chart->dataFormat;
	
	$this->chartArray_ = array();
	$this->chartArray_['caption'] = 'Total '.$_SESSION['Profile'];	

	$this->dataSource_ = array();
	
	$this->data_ = $chartDataFormat->getResultSet();
	
	}

public function createJSONString()
{
	return json_encode($this->chartString_);
}	


	public function __destruct()
	{}


}
