<?php
class Chart
{
	protected  $chart_;
	public __construct($caption,$subcaption,$theme)
	{
		$this->chart_ = array();
		$arrayItem = array();
        $arrayItem['caption'] = $caption;
        $arrayItem['subcaption'] = $subcaption;
        $arrayItem['theme'] = $theme;
        //append the above created object into the main array.
        array_push($this->chart_, $arrayItem);
		
	}
	public get_chart()
	{
		return $this->chart_;
	}
/*
     3d stacked

        "chart": {
            "caption": "Needs by Sample Size",
            "subCaption": "For selected year",
            "xAxisname": "Quarter",
            "yAxisName": "",
            "showSum": "1",
            "numberPrefix": "",
            "theme": "fint"
        },

		pie3d
            "chart": {
                "caption": "Total by Province",
                "subcaption": "Last year",
                "entityFillHoverColor": "#cccccc",
                "numberScaleValue": "1,1000,1000",
                "numberScaleUnit": ",K,M",
                "numberPrefix": "",
                "showLabels": "1",
                "theme": "fint"
            },
			
	maps/southafrica
	 "chart":    {"caption": 'Total '+selection+' Needs by Province',
                "subcaption": year,
                "entityFillHoverColor": "#cccccc",
                "numberScaleValue": "1,1000,1000",
                "numberScaleUnit": ",K,M",
                "numberPrefix": "",
                "showLabels": "1",
	           "theme": "zune"},
	column3d
	"chart":  ("caption": "Needs by "+selection+" Sub-Categories",
        "xAxisName": "Province",
        "yAxisName": selection+'',
        "rotatevalues": "1",
"theme": "zune"
}
,


*/
}