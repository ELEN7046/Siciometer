<?php
class SQLQuery
{
	protected  $tableName_;
	protected  $statement_;

	public function __construct()
	{
	}
    public function SelectCustom($columns,$from,$where,$groupby,$orderby)
	{
		if(isset($columns))
		{
		$this->statement_ = "SELECT ".$columns[0];
		 for( $tmp_i = 1; $tmp_i < count($columns); $tmp_i++)
		 {
			$this->statement_ .= ",".$columns[$tmp_i];
		 }
		}
		else 
		{
			$this->statement_ = "SELECT *";
		}
		 
		if(isset($from))
		{
		 $this->statement_ .= "
		 FROM ".$from[0];
		 for( $tmp_i = 1; $tmp_i < count($from); $tmp_i++)
		 {
			$this->statement_ .= ",".$from[$tmp_i];
		 }
		}
		else
		{
				 $this->statement_ .= "
		 FROM ".$rhis->tableName_;
		}
		if(isset($where))
		{
		 $this->statement_ .= "
		 WHERE ".$where[0];
		 for( $tmp_i = 1; $tmp_i < count($where); $tmp_i++)
		 {
			$this->statement_ .= "
			AND ".$where[$tmp_i];
		 }
		}
		 if(isset($groupby))
		 {
		 $this->statement_ .= "
		 GROUP BY ".$groupby[0];
		 for( $tmp_i = 1; $tmp_i < count($groupby); $tmp_i++)
		 {
			$this->statement_ .= ",".$groupby[$tmp_i];
		 }
		 }
		 
		 if(isset($orderby))
		 {
		 $this->statement_ .= "
		 ORDER BY ".$orderby[0];
		 for( $tmp_i = 1; $tmp_i < count($orderby); $tmp_i++)
		 {
			$this->statement_ .= ",".$orderby[$tmp_i];
		 }
		 }
		 return $this->statement_;
		 
		 
		
	}
	
	public function __destruct()
	{
			
	}
	
}