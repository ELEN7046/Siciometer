<?php
class Chart
{
	protected  $caption_;
	protected  $subcaption_;
	protected  $entityFillHoverColor_;
	protected  $numberScaleValue_;
	protected  $numberScaleUnit_;
	protected  $numberPrefix_;
	protected  $showLabels_;
	protected  $theme_;
}