<?php
spl_autoload_register(function ($class_name){
	include $class_name.'.php';
});
class ColorObject
{
	protected  $colorobject_;
	public __construct($maxvalue,$displayvalue,$label)
	{
		$this->colorobject_ = array();
		$arrayItem = array();
        $arrayItem['maxvalue'] = $maxvalue;
        $arrayItem['displayvalue'] = $displayvalue;
        $arrayItem['label'] = $label;
        //append the above created object into the main array.
        array_push($this->colorobject_, $arrayItem);
		
	}
	public get_colorobject()
	{
		return $this->colorobject_;
	}	
}