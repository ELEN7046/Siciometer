<?php
spl_autoload_register(function ($class_name){
	include $class_name.'.php';
});

unset($_SESSION);

if( !isset($_SESSION['last_access']) || (time() - $_SESSION['last_access']) > 60 ) 
{
  $_SESSION['last_access'] = time(); 
}

setSessionParametersFromQueryString($parameters = array('sel','cat','view','year','need','viewsel'));
//var_dump($_SESSION);
//http://localhost/7046/view/index.php?sel=edu&view=Province&viewsel=Gauteng
function setSessionParametersFromQueryString($parameters = array('sel','cat','view','year','need','viewsel'))
{
$current_url = str_replace("www.", "", curPageURL());
$query = parse_url(curPageURL(), PHP_URL_QUERY);//parse_url('http://www.example.com?test=123&random=abc', PHP_URL_QUERY);
parse_str($query, $params);

for( $tmp_i = 0; $tmp_i < count($parameters); $tmp_i++)
    {		
	if(!isset($_SESSION[$parameters[$tmp_i]]) AND isset($params[$parameters[$tmp_i]])) 
	{
	 $_SESSION[$parameters[$tmp_i]] = $params[$parameters[$tmp_i]];
	}
    }
	
if(!isset($_SESSION['views']))
{
   $_SESSION['views'] = array('Province','District','LocalMunicipality');
}

if(isset($_SESSION['view'])) 
{
if($_SESSION['view']== 'province')//provincial view selected
  {
	  $_SESSION['view_pos'] = 1;
	  
	  
  }
 else if($_SESSION['view']== 'district')//district view selected
  {
	   $_SESSION['view_pos'] = 2;
  }
   else //national view selected
  {
   $_SESSION['view']='national';
   $_SESSION['view_pos'] = 0;
  }
  /*
 else if($_SESSION['region']== 'local')//district view selected
  {
	   $_SESSION['view_pos'] = 2;
  }
  */
  
}
 else //national view selected
  {
   $_SESSION['view']='national';
   $_SESSION['view_pos'] = 0;
  }
	
if(isset($_SESSION['sel'])) 
{
  if($_SESSION['sel']== 'doc')//documentation selected
  {
	 $_SESSION['profile'] ='Documentation';
	  if(!isset($_SESSION['doc']))
	  {
	$_SESSION['doc'] = json_decode(file_get_contents('http://localhost/7046/view/getDocumentationProfile.php'),true); 
	  }
	$_SESSION['columns'] = array('TotalsBC','TotalsDC','TotalsPP','TotalsRP','TotalsMC','TotalsID','TotalDocNeeds');//'DocNeed'
	$_SESSION['columns_labels'] = array('Birth Certs.','Death Certs.','Passports','Res. Permts.','Marriage Certs.','IDs','Total');//'DocNeed'
	$_SESSION['need'] = 'DocNeed';
//'CaptureYear','Province','District','LocalMunicipality',

  }
  else if($_SESSION['sel'] == 'edu')//education selected
  {
	  $_SESSION['profile'] ='Education';
	  if(!isset($_SESSION['edu']))
	  {
		 $_SESSION['edu'] = json_decode(file_get_contents('http://localhost/7046/view/educationneeds.json'),true); 
	  }
	$_SESSION['columns'] = array('abet','feeding','fees','textbooks','transport','value');  //"educationneed"
	$_SESSION['columns_labels'] = array('ABET','Feeding','Fees','Textbooks','Transport','Total'); 
	$_SESSION['need'] = 'educationneed';
 
  }
   else if($_SESSION['sel'] == 'health')//health selected
  {
	  	 $_SESSION['profile'] ='Health';
	  	$_SESSION['columns']  = array('HasPermanentDisability','HaveDifficultyCommunication','HaveDifficultyHearing','HaveDifficultyPhysical','HaveDifficultySelfCare',
		'HaveDifficultyVisual','NeedFemaleHealthServiceFamilyPlanning','NeedFemaleHealthServicePMTCT','NeedFemaleHealthServicePapSmear','NeedFemaleHealthServicePrePostNatalCare','NeedHealthServiceAssistiveDevice',
		'NeedHealthServiceCheckup','NeedHealthServiceImmu','NeedHealthServiceNutrition','NeedHealthServiceRTC','NeedHealthServiceRehab','NeedHealthServiceTreatment','NeedHealthServiceVTC','NeedHealthServiceWeight',
		'PermanentDifficultyCommunication','PermanentDifficultyHearing','PermanentDifficultyMental','PermanentDifficultyPhysical','PermanentDifficultySelfCare','PermanentDifficultyVisual','Needs','UsesChronicMedication',
		'UsesGlasses','UsesHearingAid','UsesWalkingStickFrame','UsesWheelchair');  
 
  }
   else //if($sel == 'socio')//socio selected
  {
	  	 $_SESSION['profile'] ='Socio-Economic';
	 	$_SESSION['columns'] = array();
  }
}

}




function curPageURL() {
 $pageURL = 'http';
 //if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 //echo'Page URL: '.$pageURL;

 return $pageURL;
}
?>

<html>
<head>
<title>Social Barometer powered by FusionCharts Suite XT</title>
<style>
body {
    margin: 0;
    padding: 0;
    width: 100%;
    background-color: #00406A;
    font-family: Tahoma, Helvetica, Arial, sans-serif;
}
h1, h2, h3, h4, h5 {
    margin: 0;
    padding: 0;
    font-weight: bold;
}
.chartCont {
    padding: 0px 12px;
}
.border-bottom {
    border-bottom: 1px dashed rgba(0, 117, 194, 0.2);
}
.border-right {
    border-right: 1px dashed rgba(0, 117, 194, 0.2);
}
#container {
    width: 1200px;
    margin: 0 auto;
    position: relative;
}
#container> div {
    width: 100%;
    background-color: #ffffff;
}
#logoContainer {
    float: left;
}
#logoContainer img {
    padding: 0 10px;
}
#logoContainer div {
    position: absolute;
    top: 8px;
    left: 95px;
}
#logoContainer div h2 {
    color: #0075c2;
}
#logoContainer div h4 {
    color: #0e948c;
}
#logoContainer div p {
    color: #719146;
    font-size: 12px;
    padding: 5px 0;
}

#userDetail {
    float: right;
}
#userDetail img {
    position: absolute;
    top: 16px;
    right: 130px;
}
#userDetail div {
    position: absolute;
    top: 15px;
    right: 20px;
    font-size: 14px;
    font-weight: bold;
    color: #0075c2;
}
#userDetail div p {
    margin: 0;
}
#userDetail div p:nth-child(2) {
    color: #0e948c;
}
#header div:nth-child(3) {
    clear: both;
    border-bottom: 1px solid #0075c2;
}
#content div {
    display: inline-block;
}
#content > div {
    margin: 0px 20px;
}
#content > div:nth-child(1) > div {
    margin: 20px 0 0;
}
#content > div:nth-child(2) > div {
    margin: 0 0 20px;
}
#footer p {
    margin: 0;
    font-size: 9pt;
    color: black;
    padding: 5px 0;
    text-align: center;
}
</style>
  <script type="text/javascript" src="http://localhost/7046/fusioncharts/js/jquery-2.2.4.min.js"></script>
  <script type="text/javascript" src="http://localhost/7046/fusioncharts/js/fusioncharts.js"></script>
  <script type="text/javascript" src="http://localhost/7046/fusioncharts/js/fusioncharts.charts.js"></script>
  <script type="text/javascript" src="http://localhost/7046/fusioncharts/js/themes/fusioncharts.theme.zune.js"></script>
  <script type="text/javascript" src="http://localhost/7046/fusioncharts/js/app.js"></script>
<script type="text/javascript" src="http://localhost/7046/fusioncharts/js/themes/fusioncharts.theme.fint.js"></script>
<script type ="text/javascript" src="http://localhost/7046/fusioncharts/js/menu.js" ></script>
 <!-- <link href="fusioncharts/assets/css/menu.css" type="text/css" rel="stylesheet"> !-->
 
<script type="text/javascript">
FusionCharts.ready(function () {
<?php
$mapChart = new CreateMapChart();
$pieChart = new CreatePieChart();
$columnChart = new CreateColumnChart();
$stackedChart = new CreateStackedChart();
echo $mapChart->createMapString($_SESSION['views'][$_SESSION['view_pos']]);

echo $pieChart->createChartString($_SESSION['views'][$_SESSION['view_pos']]);

echo $columnChart->createChartString($_SESSION['views'][$_SESSION['view_pos']]);

echo $stackedChart->createChartString($_SESSION['views'][$_SESSION['view_pos']]);
?>	  

});
</script>
</head>
<body>
    <div>
        <a href="menu1.html" class="menulink">All</a>
        <ul class="menu" id="menu1">
            <li><a href="#">Documentation</a></li>
            <li><a href="#">Education</a></li>
            <li><a href="#">Health</a></li>
        </ul>
    </div>
    <div>
        <a href="menu1.html" class="menulink">Documentation</a>
        <ul class="menu" id="menu1">
            <li><a href="#">IDs</a></li>
            <li><a href="#">Birth Certs.</a></li>
            <li><a href="#">Death Certs.</a></li>
            <li><a href="#">Marriage Certs.</a></li>
			<li><a href="#">Passports</a></li>
			<li><a href="#">Resident Permits.</a></li>
        </ul>
    </div>
    <div>
        <a href="menu2.html" class="menulink">Social</a>
        <ul class="menu" id="menu2">
            <li><a href="#">something2</a></li>
            <li><a href="#">nothing2</a></li>
            <li><a href="#">anything2</a></li>
            <li><a href="#">everything2</a></li>
        </ul>
    </div>
    <div>
        <a href="menu3.html" class="menulink">Health</a>
        <ul class="menu" id="menu3">
            <li><a href="#">something3</a></li>
            <li><a href="#">nothing3</a></li>
            <li><a href="#">anything3</a></li>
            <li><a href="#">everything3</a></li>
        </ul>
    </div>
    <div>
        <a href="menu4.html" class="menulink">By Region</a>
        <ul class="menu" id="menu4">
            <li><a href="#">Province</a></li>
            <li><a href="#">District</a></li>
            <li><a href="#">Local Munic</a></li>
        </ul>
    </div>

<div id='container'>
    <div id='header'>
        <div id='logoContainer'>
            <img src="http://static.fusioncharts.com/sampledata/images/Logo-HM-72x72.png" alt='Logo' />
            <div>
                  <h2>Social Barometer</h2>

                  <h4>Los Angeles Topanga</h4>
                    <p>Today: 4th June, 2014</p>

            </div>
        </div>
        <div id='userDetail'>
            <img src="http://static.fusioncharts.com/sampledata/images/user_image.jpg" alt='Logo' />
            <div>
                <p>Welcome John</p>
                <p>Store Manager</p>
            </div>
        </div>
        <div></div>
    </div>
    <div class='border-bottom' id='content'>
      <div class='border-bottom'>
        <div class='chartCont border-right' id='needsMapContainer'>FusionCharts will load here.</div>
        <div class='chartCont' id='pieChartContainer'>FusionCharts will load here.</div>
      </div>
      <div>
        <div class='chartCont border-right' id='columnChartContainer'>FusionCharts will load here.</div>
        <div class='chartCont' id='stackedChartContainer'>FusionCharts will load here.</div>
      </div>
    </div>
    <div id='footer'>
        <p>This application was built using <a href="http://www.fusioncharts.com" target="_blank" title="FusionCharts - Data to delight... in minutes"><b>FusionCharts Suite XT</b></a>
</p>
    </div>
</div>
</body>
</html>