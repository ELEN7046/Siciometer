<?php
spl_autoload_register(function ($class_name){
	include $class_name.'.php';
});
class ColumnChart extends Chart
{
	public __construct($caption,$subcaption,$theme,$xAxisname,$yAxisName,$rotatevalues)
	{
		parent::__construct($caption,$subcaption,$theme);
		$arrayItem = array();
        $arrayItem['xAxisname'] = $xAxisname;
        $arrayItem['yAxisName'] = $yAxisName;
        $arrayItem['rotatevalues'] = $rotatevalues;
        //append the above created object into the main array.
        array_push($this->chart_, $arrayItem);
		
	}
/*
     3d stacked

        "chart": {
            "caption": "Needs by Sample Size",
            "subCaption": "For selected year",
            "xAxisname": "Quarter",
            "yAxisName": "",
            "showSum": "1",
            "numberPrefix": "",
            "theme": "fint"
        },

		pie3d
            "chart": {
                "caption": "Total by Province",
                "subcaption": "Last year",
                "entityFillHoverColor": "#cccccc",
                "numberScaleValue": "1,1000,1000",
                "numberScaleUnit": ",K,M",
                "numberPrefix": "",
                "showLabels": "1",
                "theme": "fint"
            },
			
	maps/southafrica
	 "chart":    {"caption": 'Total '+selection+' Needs by Province',
                "subcaption": year,
                "entityFillHoverColor": "#cccccc",
                "numberScaleValue": "1,1000,1000",
                "numberScaleUnit": ",K,M",
                "numberPrefix": "",
                "showLabels": "1",
	           "theme": "zune"},
	column3d
	"chart":  ("caption": "Needs by "+selection+" Sub-Categories",
        "xAxisName": "Province",
        "yAxisName": selection+'',
        "rotatevalues": "1",
"theme": "zune"
}
,


*/
}