<?php
spl_autoload_register(function ($class_name){
	include $class_name.'.php';
});
class GetDocumentationProfile
{
	protected $dbConnection_;
	protected $sqlSelectQueryStatement_;
	protected $query_;
	protected $databaseResult_;
	public function __construct()
	{
		$columnsArray = array('CaptureYear','Province','District','LocalMunicipality','DocNeed','TotalsBC','TotalsDC','TotalsPP','TotalsRP','TotalsMC','TotalsID','TotalDocNeeds');
        $fromArray = array('tbl_7046provincedistrictlocaldocumentationneedssummary');
        $groupbyArray = array('Province','District','LocalMunicipality');
        $whereArray = null;
        $orderbyArray = array('1','2','3');
		$this->dbConnection_ = new DatabaseConnection($server="localhost",$database="waronpoverty",$userName="test",$password_ ="YPMU7MfTf53BshAB",$port=3306);
		$this->sqlSelectQueryStatement_ = new SelectSQLQueryStatement($columns=$columnsArray,$from=$fromArray,$where=$whereArray,$groupby=$groupbyArray,$orderby=$orderbyArray);
	}
	public function getProfileFromDatabase()
	{
	$this->dbConnection_->createDatabaseConnection();
	$this->query_ = $this->sqlSelectQueryStatement_->getSelectSQLQueryStatement();
    $this->databaseResult_ = $this->dbConnection_->executeQuery($this->query_);
	$this->dbConnection_->closeDatabaseConnection();
	}

	public function getProfileFromDatabaseAsJSON()
	{
    $this->getProfileFromDatabase();
	$jsonArray = array();
    $jsonArrayItem = array();
    while($row = $this->databaseResult_->fetch_assoc()) {

    for( $tmp_i = 0; $tmp_i < count($this->sqlSelectQueryStatement_->getColumns()); $tmp_i++)
    {
		$jsonArrayItem[$this->sqlSelectQueryStatement_->getColumns()[$tmp_i]] = $row[$this->sqlSelectQueryStatement_->getColumns()[$tmp_i]];
    }
      array_push($jsonArray, $jsonArrayItem);
	}
	return $jsonArray;
	
	}

	public function __destruct()
	{}
}

//set the response content type as JSON
header('Content-type: application/json');
//output the return value of json encode using the echo function. 
$profile = new GetDocumentationProfile();
echo json_encode($profile->getProfileFromDatabaseAsJSON());
/*
$test_str = json_encode($profile->getProfileFromDatabaseAsJSON());
echo $test_str;
echo ''.PHP_EOL;
$test_str = json_decode($test_str,true);
 for( $tmp_i = 0; $tmp_i < count($test_str); $tmp_i++)
    {
		
    for( $tmp_j = 0; $tmp_j < count($this->sqlSelectQueryStatement_->getColumns()); $tmp_j++)
    {
		echo $test_str[$tmp_i][$profile->getColumnsArray()[$tmp_j]].'|';
    }
	echo '<br/>';
    }
*/


