<?php
class DataSource
{
	protected  $chart_;
	//protected  $colorrange_;
	//protected  $dataset_;

}