<?php
spl_autoload_register(function ($class_name){
	include $class_name.'.php';
});
class Color
{
	protected  $colors_;
	
	public __construct($colorobject)
	{
		$this->colors_= array();
        //append the above created object into the main array.
        array_push($this->colors_, $colorobject);
		
	}
	public get_colors()
	{
		return $this->colors_;
	}	
	public insert_color($colorobject)
	{
		//append the above created object into the main array.
        array_push($this->colors_, $colorobject);
	}	
}
