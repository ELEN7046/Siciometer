<?php
spl_autoload_register(function ($class_name){
	include $class_name.'.php';
});
class Colorrange
{

	protected  $colorrange_;
	public __construct($minvalue,$startlabel,$endlabel,$code,$gradient,$color)
	{
		$this->colorrange_ = array();
		$arrayItem = array();
        $arrayItem['minvalue'] = $minvalue;
        $arrayItem['startlabel'] = $startlabel;
        $arrayItem['endlabel'] = $endlabel;
        $arrayItem['code'] = $code;
		$arrayItem['gradient'] = $gradient;
        $arrayItem['color'] = $color;
        //append the above created object into the main array.
        array_push($this->colorrange_, $arrayItem);
		
	}
	public get_colorrange()
	{
		return $this->colorrange_;
	}
}