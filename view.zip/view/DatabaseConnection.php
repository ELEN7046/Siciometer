<?php
class DatabaseConnection
{
	protected  $server_;
	protected  $userName_;
	protected  $database_;
	protected  $password_;	
	protected  $tableName_;
	protected  $port_;
	protected  $query_;
	protected  $db_connection_;	

	public function __construct($server,$database,$userName,$password,$port)
	{
	$this->server_ = $server;
	$this->userName_ = $userName;
	$this->database_ = $database;
	$this->password_ = $password;	
	$this->port_ = $port;
	
	}
	public function createDatabaseConnection()
	{
		if(isset( $this->db_connection_))
		{
			return $this->db_connection_;
		}		
		else{
		$this->db_connection_ = new mysqli($this->server_.':'.$this->port_ , $this->userName_, $this->password_, $this->database_);
		if ($this->db_connection_->connect_error) 
		{
         die("Connection failed: " . $this->db_connection_->connect_error);
        }
		}
		return $this->db_connection_;
		
	}
	public function executeQuery($sqlQuery)
	{
		
       return $this->db_connection_->query($sqlQuery);
		  
	}
	
	public function closeDatabaseConnection()
	{
		if(isset( $this->db_connection_))
		{
			//Closing the connection to DB
			$this->db_connection_->close();
		}		
	}
	public function __destruct()
	{
	}
	
}