<?php
class Categories
{
	protected  $category_;
	protected  $dataset_;
}