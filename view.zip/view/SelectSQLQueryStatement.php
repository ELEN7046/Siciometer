<?php
class SelectSQLQueryStatement
{
	protected  $statement_;
    protected  $columns_;
	protected  $tables_;
	protected  $conditions_;
	protected  $groupings_;
	protected  $orderings_;
	public function __construct($columns,$from,$where,$groupby,$orderby)
	{
			$this->columns_ = $columns;
			$this->tables_ = $from;
			$this->conditions_ = $where;
			$this->groupings_ = $groupby;
			$this->orderings_ = $orderby;
			$this->buildStatement();
		
	}
	public function getSelectSQLQueryStatement(){ return $this->statement_;}
    public function getColumns(){ return $this->columns_;}
	public function getTables(){ return $this->tables_;}
	public function getConditions(){ return $this->conditions_;}
	public function getGroupings(){ return $this->groupings_;}
	public function getOrderings_(){ return $this->orderings_;}
	
	public function setParameters($columns,$from,$where,$groupby,$orderby)
	{
			$this->columns_ = $columns;
			$this->tables_ = $from;
			$this->conditions_ = $where;
			$this->groupings_ = $groupby;
			$this->orderings_ = $orderby;
			$this->buildStatement();
		
	}
    public  function buildStatement()
	{
		if(isset($this->columns_))
		{
		$this->statement_ = "SELECT ".$this->columns_[0];
		 for( $tmp_i = 1; $tmp_i < count($this->columns_); $tmp_i++)
		 {
			$this->statement_ .= ",".$this->columns_[$tmp_i];
		 }
		}
		else 
		{
			$this->statement_ = "SELECT *";
		}
		 
		if(isset($this->tables_))
		{
		 $this->statement_ .= "
		 FROM ".$this->tables_[0];
		 for( $tmp_i = 1; $tmp_i < count($this->tables_); $tmp_i++)
		 {
			$this->statement_ .= ",".$this->tables_[$tmp_i];
		 }
		}

		if(isset($this->conditions_ ))
		{
		 $this->statement_ .= "
		 WHERE ".$this->conditions_ [0];
		 for( $tmp_i = 1; $tmp_i < count($this->conditions_ ); $tmp_i++)
		 {
			$this->statement_ .= "
			AND ".$this->conditions_ [$tmp_i];
		 }
		}
		 if(isset($this->groupings_))
		 {
		 $this->statement_ .= "
		 GROUP BY ".$this->groupings_[0];
		 for( $tmp_i = 1; $tmp_i < count($this->groupings_); $tmp_i++)
		 {
			$this->statement_ .= ",".$this->groupings_[$tmp_i];
		 }
		 }
		 
		 if(isset($this->orderings_))
		 {
		 $this->statement_ .= "
		 ORDER BY ".$this->orderings_[0];
		 for( $tmp_i = 1; $tmp_i < count($this->orderings_); $tmp_i++)
		 {
			$this->statement_ .= ",".$this->orderings_[$tmp_i];
		 }
		 }
		 return $this->statement_;
		 
		 
		
	}
	
	public function __destruct()
	{
			
	}
	
}